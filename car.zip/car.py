# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 19:10:34 2018

@author: swojc
"""
# Implementing car object
# create Car class and member variables
class Car(object):
    
    def __init__(self):
        self.__colour = ''
        self.__make = ''
        self.__model = ''
        self.__mileage = 0
        self.__numberFuelCells = ''
        self.__engineSize = ''

#setter and getters
        
    def setColour(self, colour):
        self.__colour = colour
        
    def getColour(self):
        return self.__colour
    
    def setMake(self, make):
        self.__make = make
        
    def getMake(self):
        return self.__make
    
    def setModel(self, model):
        self.__model = model
        
    def getModel(self):
        return self.__model
        
    def setMileage(self, mileage):
        self.__mileage = mileage
        
    def getMileage(self):
        return self.__mileage
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__numberFuelCells = numberFuelCells
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setEngineSize(self, engineSize):
        self.__engineSize = engineSize
        
    def getEngineSize(self):
        return self.__engineSize
    
    
    
    def move(self, distance):
        print('Moved ' + str(distance) + 'kms')
        self.__mileage = self.__mileage + distance          
        
    def paint(self, colour):
        print('Getting a paint job - new colour is: ' + colour)
        self.__colour =  colour

# create 4 classes of car: electric, petrol, diesel and hybrid
        
class ElectricCar(Car):
    def __init__(self):
        Car.__init__(self)
        self.__numberFuelCells = 1
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__numberFuelCells = numberFuelCells
        
class PetrolCar(Car):
     def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        self.__numberCylinders = '' 
        
     def getEngineSize(self):
        return self.__engineSize
    
     def setEngineSize(self, engineSize):
        self.__engineSize = engineSize
    
     def getNumberCylinders(self):
         return self.__numberCylinders
    
     def setNumberCylinders(self,numberCylinders):
         self.__numberCylinders=numberCylinders
        
class DieselCar(Car):
    def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        
    def getEngineSize(self):
        return self.__engineSize
    
    def setEngineSize(self, engineSize):
        self.__engineSize = engineSize
        
    def getNumberCylinders(self):
        return self.__numberCylinders
            
    def setNumberCylinders(self, numberCylinders):
        self.__numberCylinders = numberCylinders
        
class HybridCar(Car):
    def __init__(self):
        Car.__init__(self)
        self.__numberFuelCells = 1
        self.__numberCylinders = '' 
        
    def getNumberFuelCells(self):
        return self.__numberFuelCells
    
    def setNumberFuelCells(self, numberFuelCells):
        self.__numberFuelCells = numberFuelCells
        
    def getNumberCylinders(self):
        return self.__numberCylinders
    
    def setNumberCylinders(self,numberCylinders):
        self.__numberCylinders=numberCylinders 
        

