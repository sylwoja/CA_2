# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 20:32:33 2018

@author: swojc
"""

import unittest
from car import Car
from carApp import AungierCarFleet

class TestCar(unittest.TestCase):

    def setUp(self):
        print("Setup")
        self.rental_pool = 40
        self.fleet = AungierCarFleet()
        
    def testRentCar(self):
        # test if you can rent a car and compare it with the stock available for each type
        self.assertTrue(self.fleet.rent("P"))
        self.assertEqual(19, len(self.fleet.getPetrolCars()))
        self.assertTrue(self.fleet.rent("E"))
        self.assertEqual(3, len(self.fleet.getElectricCars()))
        self.assertTrue(self.fleet.rent("D"))
        self.assertEqual(7, len(self.fleet.getDieselCars()))
        self.assertTrue(self.fleet.rent("H"))
        self.assertEqual(7, len(self.fleet.getHybridCars()))
        
    # test failed attempts
        self.assertFalse(self.fleet.rent("A"))
        
    def testReturnCar(self):
        self.assertTrue(self.fleet.rent("P"))
        self.assertEqual(19, len(self.fleet.getPetrolCars()))
        self.assertTrue(self.fleet.returnCar("P"))
        self.assertEqual(20, len(self.fleet.getPetrolCars()))
        
        self.assertTrue(self.fleet.rent("E"))
        self.assertEqual(3, len(self.fleet.getElectricCars()))
        self.assertTrue(self.fleet.returnCar("E"))
        self.assertEqual(4, len(self.fleet.getElectricCars()))
        
        self.assertTrue(self.fleet.rent("D"))
        self.assertEqual(7, len(self.fleet.getDieselCars()))
        self.assertTrue(self.fleet.returnCar("D"))
        self.assertEqual(8, len(self.fleet.getDieselCars()))
        
        self.assertTrue(self.fleet.rent("H"))
        self.assertEqual(7, len(self.fleet.getHybridCars()))
        self.assertTrue(self.fleet.returnCar("H"))
        self.assertEqual(8, len(self.fleet.getHybridCars()))
        
    # test failed asserts
        self.assertFalse(self.fleet.returnCar("A"))


if __name__ == '__main__':
    unittest.main()
