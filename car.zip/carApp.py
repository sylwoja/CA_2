
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 21:25:09 2018

@author: swojc
"""
from car import Car, PetrolCar, DieselCar, ElectricCar, HybridCar


class AungierCarFleet(object):
    def __init__(self):
        self.__petrol_cars = []
        self.__diesel_cars = []
        self.__electric_cars = []
        self.__hybrid_cars = []
        # setting the maximum number of cars available for rent
        self.totalDiesel = 8 
        self.totalPetrol = 20
        self.totalElectric = 4
        self.totalHybrid = 8
        for i in range(self.totalPetrol):
            self.__petrol_cars.append(PetrolCar())
        for i in range(self.totalDiesel):
            self.__diesel_cars.append(DieselCar())
        for i in range(self.totalElectric):
            self.__electric_cars.append(ElectricCar())
        for i in range(self.totalHybrid):
            self.__hybrid_cars.append(HybridCar())
        
    def getPetrolCars(self):
        return self.__petrol_cars
        
    def getElectricCars(self):
       return self.__electric_cars
       
    def getDieselCars(self):
        return self.__diesel_cars
        
    def getHybridCars(self):
       return self.__hybrid_cars

            
# function to check the stock for available cars
            
    def checkCarsInStock(self):
        print('Petrol cars available: ', str(len(self.getPetrolCars())))
        if len(self.getPetrolCars()) == 0:
            print("I'm sorry, we don't have any petrol cars available at the moment, please choose a different Type")
        elif len(self.getPetrolCars()) >= 21: # only 20 available
            print("Invalid input. Something went wrong. Please try again.")
        
        
        print('Electric cars available: ', str(len(self.getElectricCars())))
        if len(self.getElectricCars()) == 0:
            print("I'm sorry, we don't have any electric cars available at the moment, please choose a different type")
        elif len(self.getElectricCars()) >= 5:
            print("Invalid input. Something went wrong. Please try again.")
        
        print('Diesel cars available: ', str(len(self.getDieselCars())))
        if len(self.getDieselCars()) == 0:
            print("I'm sorry, we don't have any diesel cars available at the moment, please choose a different type")
        elif len(self.getDieselCars()) >=9:
            print("Invalid input. Something went wrong. Please try again.")
        
        print('Hybrid cars available: ', str(len(self.getHybridCars())))
        if len(self.getHybridCars()) == 0:
            print("I'm sorry, we don't have any hybrid cars available at the moment, please choose a different type")
        elif len(self.getHybridCars()) >=9:
            print("Invalid input. Something went wrong. Please try again.")
        if (len(self.getPetrolCars())==0 and len(self.getElectricCars())==0 and len(self.getDieselCars())==0 and len(self.getHybrid())==0):# if the nr of cars  = 0 the user will receive the below comment
            print("We are sorry but there are no available cars at the moment. Please try again later")
        
        
#  rent function, the user is limited to available cars only
        
    def rent(self, carType):
        if carType.upper() == 'P': # allowing user to input capitlals or lower case
            # check the stock limit
            if (len(self.getPetrolCars()) > 0):
                self.__petrol_cars.pop()
                return True
             
        elif carType.upper() == 'E':
            if (len(self.getElectricCars()) > 0):
                self.__electric_cars.pop()
                return True
        elif carType.upper() == 'D':
            if (len(self.getDieselCars()) > 0):
                self.__diesel_cars.pop()
                return True
        elif carType.upper() == 'H':
            if (len(self.getHybridCars()) > 0):
                self.__hybrid_cars.pop()
                return True
        return False    
            
# return function           
            
    def returnCar(self, carType):
        # check the stock before return
        if carType.upper() == 'P':
            if (len(self.getPetrolCars()) < self.totalPetrol):
                self.__petrol_cars.append(PetrolCar)
                return True
        elif carType.upper() == 'E':
            if (len(self.getElectricCars()) < self.totalElectric):
                self.__electric_cars.append(ElectricCar)
                return True            
        elif carType.upper() == 'D':
            if (len(self.getDieselCars()) < self.totalDiesel): 
                self.__diesel_cars.append(DieselCar)
                return True
        elif carType.upper() == 'H':
            if (len(self.getHybridCars()) < self.totalHybrid):
                self.__hybrid_cars.append(HybridCar)
                return True
        return False            

# function with menu for the user
                
    def mainMenu(self):
        print('#'*30)
        print('Welcome to Aungier Car Rental')
        print('#'*30)
        
        
        keepAsking = True
        while keepAsking:
            try:
                rentedCar = None
                print('Please see the below options:')
                print(' \n1. Rent a car \n2. Return a car \n3. Exit \n')
                msg = int(input("Please choose an option from the above menu. Press 1, 2 or 3: "))
                if msg == 1:
                    print('\n\nCars available at the moment: ')
                    self.checkCarsInStock()
                    carType = input('What car would you like to rent? Press P for petrol, E for electric, D for diesel or H for hybrid: ')
                    rentedCar = self.rent(carType)
                    
                    if rentedCar == True:
                        print('\n\nYou have successfully rented a car! Thank you for choosing Aungier Car Rental')
                    else:
                        print('Incorrect input. Please choose again: P for petrol, E for electric, D for diesel or H for hybrid: ')
                        self.checkCarsInStock()
                                                           
                    continueYesNo = input("Do you wish to continue? 'Y/N': ")
                    if continueYesNo.upper() == "N":
                        print('Thank you for using the Aungier Car Rental')
                        break
                    
                
                elif msg == 2: 
                    carType = input('What car would you like to return? Press P for petrol, E for electric, D for diesel or H for hybrid?: ')
                    print(' ')
                    if carType.upper() == "P" or carType.upper() == "E" or carType.upper() == "D" or carType.upper() == "H":
                        if (self.returnCar(carType)):
                            print('\n You have successfully returned your car. Thank you for using Aungier Car Rental')
                        else:
                            print ('Error to return the car')
                        print('Please see the stock below: ')
                        self.checkCarsInStock()
                    else:
                        print('Incorrect input. Please choose again: P for petrol, E for electric, D for diesel or H for hybrid: ')
                        
                    continueYesNo = input("Do you wish to continue? 'Y/N': ")
                    if continueYesNo.upper() == "N":
                        print('Thank you for using the Aungier Car Rental.')
                        break
                elif msg == 3:
                    print('Thank you for using our service. Hope to see you again!')
                    break
                  
                else:
                    print('Your input is incorrect, please try again.Please seelct option from the menu: ')
                    print(' ')                
            except (ValueError, TypeError):
                print('Your input is incorrect.')
        #print(' ')
        #print('Cars available at the moment: ')
        #self.checkCarsInStock()

if __name__ == '__main__':        
    aungierCar=AungierCarFleet()
    aungierCar.mainMenu()

